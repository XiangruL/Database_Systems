### Instruction

~~~
java -jar [path/sqlParser.jar] [path where the schema and data file is]
~~~

* The four paramiter path: path should be end with a slash, Such as ~/UB562/

* The program cannot handle the 11th query. It may course some error. 
* This jar should be put in the same folder with schema and data files. 